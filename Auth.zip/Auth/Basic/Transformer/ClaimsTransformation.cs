﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Basic.Transformer
{
    public class ClaimsTransformation : IClaimsTransformation
    {
        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
           var hasFriendClaim = principal.Claims.Any(x => x.Type == "Friend");

            if(!hasFriendClaim)
            {
                ((ClaimsIdentity)principal.Identity).AddClaim(newClaim("friend", "bad"));
            }
            return Task.FromResult(principal);
            
            //throw new System.NotImplementedException();
        }

        private Claim newClaim(string v1, string v2)
        {
            throw new NotImplementedException();
        }
    }
}
